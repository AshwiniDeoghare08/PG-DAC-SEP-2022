/*
How to convert numeric String to an int?
For example, if you pass "67263" to the program then it should return 67263.
*/

class P9and10{
    public static void main(String args[]){
        String str = "12345";

        int i = Integer.parseInt(str);
        System.out.println(i);
    } 
}