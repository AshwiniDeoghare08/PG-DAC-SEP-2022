/*
Write a Java program to find all pairs of elements in an integer array whose sum is equal to a given number
*/
class P3{
	
	public static void main(String args[]){
		
		
	}
}